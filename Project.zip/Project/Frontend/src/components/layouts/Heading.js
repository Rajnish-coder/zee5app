import React, { Component } from "react";

export default class Heading extends Component {
  render() {
    return (
      <div className="landing-inner">
        <h1 className="x-large text-light">Welcome to Zee 5</h1>
        <p className="lead text-light fw-bold">
          A place to stream movies and WebSeries.
        </p>
      </div>
    );
  }
}
