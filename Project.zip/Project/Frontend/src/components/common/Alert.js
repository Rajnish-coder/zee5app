import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";

const Alert = ({ alerts }) => {
  // alerts.map() is used to manipulate and traverse the array.
  return (
    alerts !== null &&
    alerts.length > 0 &&
    alerts.map((alert) => (
      <div key={alert.id} className={`alert alert-${alert.alertType}`}>
        {alert.msg}
      </div>
    ))
  );
};

Alert.propTypes = {
  alerts: PropTypes.array.isRequired,
};

const mapStateToProps = (state) => ({
  alerts: state.alerts, // here state is referring to 'store()'
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Alert);
