import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";
import { getMovies } from "../../redux/actions/movieAction";
import { useEffect } from "react";
import { Fragment } from "react";
import { Link } from "react-router-dom";
import Movie from "./Movie";

const FetchMovies = ({ getMovies, movie: { movies }, auth: { user } }) => {
  useEffect(() => {
    getMovies();
  }, [getMovies]);

  var flag = null;

  if (user.roles === "ROLE_ADMIN") flag = true;

  return (
    <div className="profile-exp bg-white p-2">
      <h2 className="text-primary">Movies</h2>
      {movies.length > 0 ? (
        <Fragment>
          {movies.map((data) => (
            <Movie
              key={data.movieId}
              movieId={data.movieId}
              movieName={data.movieName}
              actors={data.actors}
              genre={data.genre}
              director={data.director}
              languages={data.languages}
              production={data.production}
              isAdmin={flag}
            />
          ))}
        </Fragment>
      ) : (
        <h4>No movies data found!</h4>
      )}
      <Link to="/dashboard" className="btn btn-outline-primary">
        Go Back
      </Link>
    </div>
  );
};

FetchMovies.propTypes = {
  getMovies: PropTypes.func.isRequired,
  movie: PropTypes.object.isRequired,
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  movie: state.movie,
  auth: state.auth,
});

const mapDispatchToProps = { getMovies };

export default connect(mapStateToProps, mapDispatchToProps)(FetchMovies);
