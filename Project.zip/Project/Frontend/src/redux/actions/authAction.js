import axios from "axios";
import api from "../../utils/api";
import { headerConfig } from "../../assets/utils/commonConfig";
import setAuthToken from "../../assets/utils/setAuthToken";
import {
  LOGIN_SUCCESS,
  REGISTER_FAIL,
  REGISTER_SUCCESS,
  LOGIN_FAIL,
  USER_LOADED,
  LOGOUT,
} from "../types";
import { setAlert } from "./alertAction";

export const loaduser = () => async (dispatch) => {
  // if token is available in localstorage then use it to get user deatils.
  // else throw the error.
  // end point=> "/api/auth".
  const userId = localStorage.getItem("userId");
  // console.log("*");
  try {
    const res = await api.get(`/auth/${userId}`);
    const user = {};
    user.username = res.data.username;
    user.roles = res.data.roles[0].roleName;
    user.userId = res.data.userId;
    console.log(res.data.roles[0].roleName);
    dispatch({ type: USER_LOADED, payload: user });
  } catch (err) {}
};

export const register = (formData, navigate) => async (dispatch) => {
  // action story
  // rest call action
  // axios call
  // console.log(formData);
  if (Array.isArray(formData.role) === false) {
    var temp = [formData.role];
    formData.role = temp;
  }
  const { username, firstName, email, password, confirmPassword, role, Obj } =
    formData;
  const data = JSON.stringify({ username, email, firstName, password, role });

  try {
    //console.log(data);
    const res = await api.post("/auth/signup", data, headerConfig);
    console.log(res);
    dispatch({ type: REGISTER_SUCCESS });
    dispatch(setAlert("User registered successfully", "success"));
    navigate("/login");
    // dispatch(loaduser());
  } catch (errors) {
    const error = errors.response.data.errors;
    console.log(errors);
    if (error) {
      error.forEach((e) => dispatch(setAlert(e.msg, "danger")));
    }

    dispatch({ type: REGISTER_FAIL });
  }
  // url
  // success part then method call ==> we have to share the details to make some changes to ur store as per the action.
  // failure catch method call ==> we have to share the failure details to make some changes to ur store as per the action
  // success/ failure action details includes 2 parts=> 1. type
  // 2. payload (data to be inserted / manipulate/deleted ) from the store.
};

export const login =
  ({ username, password }) =>
  async (dispatch) => {
    // rest call   ==> we have to share the details to make some changes to ur store as
    // end point : /api/auth

    try {
      // console.log(email, password);
      const body = JSON.stringify({ username, password });
      //console.log(body);
      const res = await api.post("/auth/signin", body, headerConfig);
      const user = {};
      user.username = res.data.username;
      user.roles = res.data.roles[0];
      user.userId = res.data.id;
      user.accessToken = res.data.accessToken;
      dispatch({ type: LOGIN_SUCCESS, payload: user });
      //  dispatch(setAlert("Logged in successfully", "success"));
      console.log(res.data);
      // dispatch(loaduser());
    } catch (err) {
      const errors = err.response.data.message;
      console.log(err.response);

      if (errors) {
        dispatch(setAlert(errors, "danger", 3000));
      }

      dispatch({
        type: LOGIN_FAIL,
      });
    }
  };

export const logout = () => async (dispatch) => {
  dispatch({ type: LOGOUT });
  dispatch(setAlert("Logged out successfully!", "success"));
};
