import {
  ADD_MOVIE,
  CLEAR_MOVIE,
  DELETE_MOVIE,
  GET_MOVIE,
  GET_MOVIES,
  UPDATE_MOVIE,
} from "../types";

const initialState = {
  movies: [],
  movie: {},
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_MOVIES:
      return { ...state, movies: payload, movie: null };
    case GET_MOVIE:
      return { ...state, movie: payload };
    case ADD_MOVIE:
      return { ...state, movie: payload };
    case DELETE_MOVIE:
      return { ...state, movie: payload };
    case UPDATE_MOVIE:
      return { ...state, movie: payload };
    case CLEAR_MOVIE:
      return { ...state, movie: null };
    default:
      return state;
  }
};
