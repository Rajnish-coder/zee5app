package com.zee.zee5app.enums;

public enum Genres {

	ACTION,
	DRAMA,
	SCI_FI,
	HORROR,
	COMEDY,
	THRILLER
}
