import PropTypes from "prop-types";
import React, { Fragment, useEffect } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import movieicon from "../../assets/img/movie.png";
import seriesicon from "../../assets/img/webseries.jpg";
import { loaduser } from "../../redux/actions/authAction";

//1. Profile details will be extracted from profile reducer. Based on the token we will extract
//   current profile details.
//2. User details are extracted from auth reducer.
//3. All experience and education details are taken from json array.

export const Dashboard = ({ auth: { isAuthenticated, user } }) => {
  const myStyle = {
    backgroundImage:
      "url('https://www.thefastmode.com/media/k2/items/src/68dfc5056ce08a29895578303d864463.jpg?t=20220126_070228')",
    height: "100vh",
    //   marginTop: "-70px",
    // fontSize: "22px",
    backgroundSize: "100% 100%",
    backgroundRepeat: "no-repeat",
  };
  var role = null;
  if (user.roles === "ROLE_ADMIN") {
    role = "Admin";
  } else role = "User";

  return (
    <Fragment>
      <div className="dark-overlay" style={myStyle}>
        <h1 className="text-light">
          Welcome {user.username}({role})!
        </h1>
        <div className="container mt-5">
          <Link to="/movie-dashboard">
            <img src={movieicon} className="m-5" />
          </Link>
          <Link to="/series-dashboard">
            <img src={seriesicon} style={{ width: "315px" }} />
          </Link>
        </div>
      </div>
    </Fragment>
  );
};

Dashboard.propTypes = {
  // second: PropTypes.third,
  auth: PropTypes.object.isRequired,
  //loaduser: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
