import PropTypes from "prop-types";
import React, { Fragment } from "react";
import { connect } from "react-redux";
import { register } from "../../redux/actions/authAction";
import { setAlert } from "../../redux/actions/alertAction";
import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";

const Register = ({ register, setAlert, isAuthenticated }) => {
  const myStyle = {
    backgroundImage:
      "url('https://www.thefastmode.com/media/k2/items/src/68dfc5056ce08a29895578303d864463.jpg?t=20220126_070228')",
    height: "100vh",
    //   marginTop: "-70px",
    // fontSize: "22px",
    backgroundSize: "100% 100%",
    backgroundRepeat: "no-repeat",
  };

  const [formData, setFormData] = useState({
    username: "",
    firstName: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "",
    Obj: {},
  });

  const { username, firstName, email, password, confirmPassword, role, Obj } =
    formData;

  const navigate = useNavigate();

  const onChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    if (formData.password === formData.confirmPassword) {
      console.log("match");
      //{ username, email, firstName, password, role, navigate }
      register(formData, navigate);
    } else {
      const errObj = {};
      errObj.confirmPassword = "password did not match";
      setFormData({ Obj: errObj });
    }
  };

  if (isAuthenticated === true) {
    return <Navigate to="/" />;
  }

  return (
    <Fragment>
      <section className="landing">
        <div className="dark-overlay p-5" style={myStyle}>
          {/* <p className="col-6 text-light">
            <i className="fas fa-user"></i> Create Your Account
          </p> */}
          <form className="form" onSubmit={onSubmit}>
            <div className="mb-3 col-6">
              <label className="form-label text-light">UserName</label>
              <input
                type="text"
                name="username"
                className="form-control"
                id="username"
                value={username}
                onChange={onChange}
                required
              />
            </div>
            <div className="mb-3 col-6">
              <label className="form-label text-light">Full Name</label>
              <input
                type="text"
                name="firstName"
                className="form-control"
                id="firstName"
                value={firstName}
                onChange={onChange}
                required
              />
            </div>
            <div className="mb-3 col-6">
              <label className="form-label text-light">Email address</label>
              <input
                type="email"
                name="email"
                className="form-control"
                id="email"
                aria-describedby="emailHelp"
                value={email}
                onChange={onChange}
                required
              />
            </div>
            <div className="mb-3 col-6">
              <label
                className="form-label text-light"
                for="exampleFormControlSelect1"
              >
                Select Role
              </label>
              <select
                className="form-control"
                id="exampleFormControlSelect1"
                name="role"
                value={role}
                onChange={onChange}
              >
                <option value="" hidden selected disabled>
                  Choose Role
                </option>
                <option value="admin">Administrator</option>
                <option value="user">User</option>
              </select>
            </div>
            <div className="mb-3 col-6">
              <label className="form-label text-light">Password</label>
              <input
                type="password"
                name="password"
                className="form-control"
                id="password"
                value={password}
                onChange={onChange}
                required
              />
            </div>
            <div className="mb-2 col-6">
              <label className="form-label text-light">Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                className="form-control"
                id="confirmPassword"
                value={confirmPassword}
                onChange={onChange}
                required
              />
              <div className="d-block invalid-feedback">
                {Obj.confirmPassword}
              </div>
            </div>

            <div className="col-6">
              <button type="submit" className="btn btn-primary px-5">
                Register
              </button>
            </div>
          </form>
        </div>
      </section>
    </Fragment>
  );
};

Register.propTypes = {
  // second: PropTypes.third
  register: PropTypes.func.isRequired,
  setAlert: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = { register, setAlert };

export default connect(mapStateToProps, mapDispatchToProps)(Register);
