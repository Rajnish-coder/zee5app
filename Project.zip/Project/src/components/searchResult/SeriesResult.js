import React from "react";

const SeriesResult = ({
  webSeriesId,
  webSeriesName,
  actors,
  director,
  languages,
  production,
  genre,
}) => {
  return (
    <div className="card bg-light m-2">
      <div className="card-body">
        <h4>WebSeries Name: {webSeriesName && webSeriesName}</h4>
        <h5>Director: {director && director}</h5>
        <h5>Genre: {genre && genre}</h5>
        <h5>Production: {genre && production}</h5>
        <h5>Actors: {actors && actors.join()}</h5>
        <h5>Languages: {languages && languages.join()}</h5>
      </div>
    </div>
  );
};

export default SeriesResult;
