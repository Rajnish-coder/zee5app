import PropTypes from "prop-types";
import React, { Fragment, useState } from "react";
import { connect } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../../redux/actions/authAction";
import { getMovieByName } from "../../redux/actions/movieAction";
import { getSerieByName } from "../../redux/actions/seriesAction";

const Navbar = ({
  auth: { isAuthenticated },
  logout,
  getMovieByName,
  getSerieByName,
}) => {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const onChange = (e) => {
    setSearch(e.target.value);
  };

  const onClick = () => {
    getMovieByName(search, navigate);
    getSerieByName(search, navigate);
  };

  const searchBox = (
    <Fragment>
      <input
        type="search"
        id="form1"
        placeholder="Search movie/series"
        value={search}
        onChange={onChange}
      />
      <button type="button" className="btn btn-primary" onClick={onClick}>
        <i class="fas fa-search"></i>
      </button>
    </Fragment>
  );

  const guestLinks = (
    <ul className="navbar-nav">
      {isAuthenticated && searchBox}
      <li>
        <Link className="nav-link" to="/register">
          Register
        </Link>
      </li>
      <li>
        <Link className="nav-link" to="/login">
          Login
        </Link>
      </li>
    </ul>
  );
  const authLinks = (
    <ul className="navbar-nav">
      {isAuthenticated && searchBox}

      <li className="ms-3">
        <Link className="nav-link" to="/dashboard">
          <i className="fas fa-user" />{" "}
          <span className="hide-sm">Dashboard</span>
        </Link>
      </li>
      <li>
        <a className="nav-link" onClick={logout} href="/">
          <i className="fas fa-sign-out-alt" />{" "}
          <span className="hide-sm">Logout</span>
        </a>
      </li>
    </ul>
  );

  return (
    <div>
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            <img
              src="https://cdn.dnaindia.com/sites/default/files/styles/full/public/2019/07/26/759898-zee5.png"
              height={36}
            />
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapsibleNavbar"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            {isAuthenticated && (
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/get-movies">
                    Movies
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/get-series">
                    WebSeries
                  </Link>
                </li>
              </ul>
            )}
          </div>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="collapsibleNavbar"
          >
            <Fragment>{isAuthenticated ? authLinks : guestLinks}</Fragment>
          </div>
        </div>
      </nav>
    </div>
  );
};

Navbar.propTypes = {
  //second: PropTypes.third,
  auth: PropTypes.object.isRequired,
  logout: PropTypes.func.isRequired,
  getMovieByName: PropTypes.func.isRequired,
  getSeriesByName: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({ auth: state.auth });

const mapDispatchToProps = { logout, getMovieByName, getSerieByName };

export default connect(mapStateToProps, mapDispatchToProps)(Navbar);
