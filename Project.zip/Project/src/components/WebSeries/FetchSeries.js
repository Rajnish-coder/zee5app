import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";
import { getSeries } from "../../redux/actions/seriesAction";
import { useEffect } from "react";
import { Fragment } from "react";
import { Link } from "react-router-dom";
import Serie from "./Serie";

export const FetchSeries = ({
  getSeries,
  series: { series },
  auth: { user },
}) => {
  useEffect(() => {
    getSeries();
  }, [getSeries]);

  var flag = null;

  if (user.roles === "ROLE_ADMIN") flag = true;
  return (
    <div className="profile-exp bg-white p-2">
      <h2 className="text-primary">Web Series</h2>
      {series.length > 0 ? (
        <Fragment>
          {series.map((data) => (
            <Serie
              key={data.webSeriesId}
              seriesId={data.webSeriesId}
              seriesName={data.webSeriesName}
              actors={data.actors}
              genre={data.genre}
              director={data.director}
              languages={data.languages}
              production={data.production}
              isAdmin={flag}
            />
          ))}
        </Fragment>
      ) : (
        <h4>No WebSeries data found!</h4>
      )}
      <Link to="/dashboard" className="btn btn-outline-primary">
        Go Back
      </Link>
    </div>
  );
};

FetchSeries.propTypes = {
  getSeries: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  series: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  series: state.series,
});

const mapDispatchToProps = { getSeries };

export default connect(mapStateToProps, mapDispatchToProps)(FetchSeries);
