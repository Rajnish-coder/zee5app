package com.zee.zee5app.utils;

public class Constants {

	public static final int MAX_SIZE=10;
}
