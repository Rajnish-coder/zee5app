package com.zee.zee5app;

import java.util.Arrays;

import com.zee.zee5app.dto.User;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          // new User();
		String[] strArr = new String[] { "1", "2", "3" };

		String ans = null;
	    ans = String.join(",", strArr);
	    System.out.println(ans);

	}

}
